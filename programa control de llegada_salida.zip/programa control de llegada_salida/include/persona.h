#ifndef PERSONA_H
#define PERSONA_H


class persona
{
    public:
        persona();
        void pedir_datos();
        void imprimir_datos();

    protected:

    private:
        int identidad;
        char NombreCompleto[60];
        char sexo;
        int edad;
};

#endif // PERSONA_H
