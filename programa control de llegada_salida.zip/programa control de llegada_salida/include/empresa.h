#ifndef EMPRESA_H
#define EMPRESA_H

#include <tiempo.h>


class empresa : public tiempo
{
    public:
        empresa();
        empresa(tiempo,tiempo);

    protected:

    private:
        tiempo hora_entrada;
        tiempo hora_final;
};

#endif // EMPRESA_H
