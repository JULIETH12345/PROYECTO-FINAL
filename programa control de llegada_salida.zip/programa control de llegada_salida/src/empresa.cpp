#include "empresa.h"

empresa::empresa()
{
    //ctor
}
empresa::empresa(tiempo,tiempo)
{

}
