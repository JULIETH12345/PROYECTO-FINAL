#include "trabajador.h"
#include <iostream>

using namespace std;


trabajador::trabajador()
{
    //ctor
}
trabajador::trabajador(tiempo t1,tiempo t2,tiempo t3,tiempo t4)
{
    hora_entrada=t1;
    hora_salida=t2;
    entrada_trabajo=t3;
    salida_trabajo=t4;


}
void trabajador::puntualidad_llegada()
{
    tiempo T1,T2,T3,T4;
    T3=hora_entrada.comparacion_tiempo(entrada_trabajo);
    T3=T3.obtener_tiempo();
    int h=T3.horas,m=T3.minutos,s=T3.segundos;
    if(h>0 && m>0 && s>0)
    {
        cout<<"acabas de igresar mas temprano";
         cout<<" tu tiempo sobrante es "<<endl;
        T3.imprimir_hora();
    }else
    cout<<"llegas con";
    cout<<"-----------------------------------------"<<endl;
    cout<<"el siguiente retraso;"<<endl;
    T3.imprimir_hora();
     cout<<endl<<"-----------------------------------------"<<endl;


}
void trabajador::puntualidad_salida()
{
    tiempo T1;

    T1=hora_salida.comparacion_tiempo(salida_trabajo);
    int h=T1.horas,m=T1.minutos,s=T1.segundos;
    if(h>0 && m>0 && s>0)
    {
     cout<<"su hora de salida se exedio en: ";
         cout<<" tu tiempo sobrante es "<<endl;
         T1.imprimir_hora();
    }else cout<<"saliste antes de lo establesdo";
    T1.imprimir_hora();

}
