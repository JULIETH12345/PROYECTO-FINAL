#ifndef TRABAJADOR_H
#define TRABAJADOR_H

#include <persona.h>
#include <tiempo.h>
#include <empresa.h>

class trabajador : public persona,tiempo,empresa
{
    public:
        trabajador();
        trabajador(tiempo,tiempo,tiempo,tiempo);
        void puntualidad_llegada();
        void puntualidad_salida();


    protected:

    private:
        tiempo hora_entrada;
        tiempo hora_salida;
        tiempo entrada_trabajo;
        tiempo salida_trabajo;
};

#endif // TRABAJADOR_H
