#include "tiempo.h"
#include <iostream>

using namespace std;


tiempo::tiempo()
{
    //ctor
}
void tiempo::pedir_hora()
{
    cout<<"hora: ";
    cin>>horas;
    cout<<"minutos: ";
    cin>>minutos;
    cout<<"segundos: ";
    cin>>segundos;
}
void tiempo::imprimir_hora()
{
    cout<<endl<<"hora: ";
    cout<<endl<<horas;
    cout<<endl<<"minutos: ";
    cout<<endl<<minutos;
    cout<<endl<<"segundos: ";
    cout<<endl<<segundos;
}
tiempo tiempo::obtener_tiempo()
{
    tiempo a;
    a.horas=horas;
    a.minutos=minutos;
    a.segundos=segundos;
    return a;
}

tiempo tiempo::comparacion_tiempo(tiempo t)
{
    tiempo st;
    st.horas=t.horas-horas;
    st.minutos=t.minutos-minutos;
    st.segundos=t.segundos-segundos;
    return st;
}
