#include <iostream>
#include "persona.h"
#include "trabajador.h"
#include "tiempo.h"
#include "empresa.h"
using namespace std;

int main()
{
    tiempo t1,t2,t3,t4;

    cout<<"hora de llegada y salida del empleado: "<<endl;
     cout<<"        hora de llegada: "<<endl;
    t1.pedir_hora();
     cout<<"        hora de salida: "<<endl;
    t2.pedir_hora();
    cout<<"hora de llegada y salida establecidas por la empresa: "<<endl;
     cout<<"        hora de llegada: "<<endl;
    t3.pedir_hora();
     cout<<"        hora de salida: "<<endl;
    t4.pedir_hora();
     cout<<"-----------------------------------------"<<endl;
    trabajador d1(t1,t2,t3,t4);
    d1.pedir_datos();
    d1.puntualidad_llegada();
    d1.puntualidad_salida();


    return 0;
}
