#ifndef TIEMPO_H
#define TIEMPO_H


class tiempo
{
    public:
        tiempo();
        void pedir_hora();
        void imprimir_hora();
        tiempo comparacion_tiempo(tiempo);
        tiempo obtener_tiempo();




        int horas;
        int minutos;
        int segundos;
};

#endif // TIEMPO_H
