#include "persona.h"
#include <iostream>

using namespace std;


persona::persona()
{

}
void persona::pedir_datos()
{
    cout<<"nombre: ";
    cin>>NombreCompleto;
    cout<<"sexo: ";
    cin>>sexo;
    cout<<"identificacion: ";
    cin>>identidad;
    cout<<"edad: ";
    cin>>edad;
}
void persona::imprimir_datos()
{
    cout<<"nombre: ";
    cout<<NombreCompleto;
    cout<<endl<<"sexo: ";
    cout<<sexo;
    cout<<endl<<"identificacion: ";
    cout<<identidad;
    cout<<endl<<"edad: ";
    cout<<edad;
}
